%% !!! DO NOT CHANGE THE FUNCTION INTERFACE, OTHERWISE, YOU MAY GET 0 POINT !!! %%
% xy: size 2xn
% XYZ: size 3xn
% xy_normalized: 3xn
% XYZ_normalized: 4xn
% T: 3x3
% U: 4x4

function [xy_normalized, XYZ_normalized, T, U] = normalization(xy, XYZ)
%data normalization

% TODO 1. compute centroids

% TODO 2. shift the points to have the centroid at the origin

% TODO 3. compute scale

% TODO 4. create T and U transformation matrices (similarity transformation)

% TODO 5. normalize the points according to the transformations

end