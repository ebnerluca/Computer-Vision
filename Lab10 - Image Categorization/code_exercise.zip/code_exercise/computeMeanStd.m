function [mu sigma] = computeMeanStd(vBoW)

end