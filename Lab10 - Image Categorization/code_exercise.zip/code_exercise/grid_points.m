function vPoints = grid_points(img,nPointsX,nPointsY,border)
    
    
end
