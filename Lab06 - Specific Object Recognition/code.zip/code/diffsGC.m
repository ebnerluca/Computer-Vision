function diffs = diffsGC(img1, img2, dispRange)

% get data costs for graph cut

end