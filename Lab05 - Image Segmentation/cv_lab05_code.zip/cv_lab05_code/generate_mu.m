% Generate initial values for mu
% K is the number of segments

function mu = generate_mu([input you need], K)

mu = [the mus you generated];

end