function [mu, var, alpha] = maximization(P, X)

K = size(prb,2);
N = size(x,1);

end