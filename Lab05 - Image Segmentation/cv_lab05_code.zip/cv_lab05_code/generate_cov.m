% Generate initial values for the K
% covariance matrices

function cov = generate_cov([input you need], K)

cov = [covariance matrices generated];

end