function P = expectation(mu,var,alpha,X)

K = length(alpha);
N = size(imgSqueezed,1);

end