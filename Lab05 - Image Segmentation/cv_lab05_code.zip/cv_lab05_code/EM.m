function [map cluster] = EM(img)

% use function generate_mu to initialize mus
% use function generate_cov to initialize covariances

% iterate between maximization and expectation
% use function maximization
% use function expectation

end